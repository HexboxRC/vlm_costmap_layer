#include <stdio.h>
#include <sys/timex.h>
int main(void) {
    struct timex tx = {0}; /* modes=0: query only, never adjust */
    int result = adjtimex(&tx);
    printf("result=%d modes=%u offset=%ld freq=%ld freq_ppm=%.6f tick=%ld status=%d precision=%ld tolerance=%ld tai=%d\n", result, tx.modes, tx.offset, tx.freq, tx.freq / 65536.0, tx.tick, tx.status, tx.precision, tx.tolerance, tx.tai);
    return result < 0;
}
